#!/bin/bash
docker exec teste_02-moodle-1 php /bitnami/moodle/admin/cli/cron.php 