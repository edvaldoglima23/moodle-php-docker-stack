<?php
// Proteção contra acesso direto
defined('MOODLE_INTERNAL') || die();

// Nome do plugin
$plugin->component = 'local_avisos';
$plugin->version = 2024052601;  
$plugin->requires = 2022041900; 
$plugin->maturity = MATURITY_BETA;
$plugin->release = 'v1.0-beta';