<?php
// Strings gerais
$string['pluginname'] = 'Avisos';
$string['title'] = 'Título';
$string['message'] = 'Mensagem';
$string['senddate'] = 'Data de envio';
$string['status'] = 'Status';
$string['status_pending'] = 'Pendente';
$string['status_sent'] = 'Enviado';
$string['add_aviso'] = 'Adicionar Aviso';
$string['edit_aviso'] = 'Editar Aviso';
$string['aviso_saved'] = 'Aviso salvo com sucesso';
$string['aviso_deleted'] = 'Aviso excluído com sucesso';
$string['aviso_not_found'] = 'Aviso não encontrado';
$string['no_avisos'] = 'Nenhum aviso disponível';

// Permissões
$string['avisos:manage'] = 'Gerenciar avisos';
$string['avisos:view'] = 'Ver avisos'; 